#!/bin/bash

kernel=3.18.11-v7+
build=781

module_bin="mt7601Usta.ko"
module_dir="/lib/modules/$kernel/kernel/drivers/net/wireless"

echo "sudo mkdir -p /etc/Wireless/RT2870STA/"
sudo mkdir -p /etc/Wireless/RT2870STA/
echo "sudo cp RT2870STA.dat /etc/Wireless/RT2870STA/"
sudo cp RT2870STA.dat /etc/Wireless/RT2870STA/
rm RT2870STA.dat

echo "sudo cp 95-ralink.rules /etc/udev/rules.d/"
sudo cp 95-ralink.rules /etc/udev/rules.d/
rm 95-ralink.rules

echo "sudo install -p -m 644 $module_bin $module_dir"
sudo install -p -m 644 $module_bin $module_dir
echo "sudo depmod $kernel"
sudo depmod $kernel
rm mt7601*

echo
echo "Reboot to run the driver."
echo
echo "If you have already configured your wifi it should start up and connect to your"
echo "wireless network."
echo
echo "If you have not configured your wifi you will need to do that to enable the wifi."

rm install.sh
